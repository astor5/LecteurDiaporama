#ifndef DIAPORAMA_H
#define DIAPORAMA_H
#include "image.h"
#include <vector>



void creerDiaporama (Diaporama* pDiaporama)

#endif // DIAPORAMA_H
